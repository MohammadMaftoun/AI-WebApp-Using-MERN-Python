# Iris ML Web App (Modularized + Fixed)

This repository contains a modularized, improved version of the MERN + Python ML project:
- AI model served with FastAPI (trained models saved under `ai-model/models/`)
- Express backend (modular routes & models)
- React frontend (components)
- Docker Compose for local orchestration

## What's changed / added
- **Backend**: modular structure (`config/db.js`, `models/Prediction.js`, `routes/predict.js`, `routes/stats.js`, `app.js`) and robust input validation (handles zeros correctly).
- **AI model**: saves models into `ai-model/models/`. FastAPI returns a 503 if models are missing and provides more robust error messages.
- **Frontend**: decomposed into components (`PredictionForm`, `Result`, `History`). Uses `REACT_APP_API_URL` and improved input handling.
- **Env examples**: `.env.example` files for backend and Docker-friendly defaults.
- **Docker**: minor improvements in service names and health checks.
- **Zip**: this package is provided as `iris_ml_project.zip`.

## Quick start (local)
1. Train models:
   ```bash
   cd ai-model
   python -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   python model.py
   ```
2. Start FastAPI:
   ```bash
   python app.py
   ```
3. Start backend:
   ```bash
   cd backend
   npm install
   npm start
   ```
4. Start frontend:
   ```bash
   cd frontend
   npm install
   npm start
   ```

## Notes
- This repo aims to be a pragmatic, modular starting point. For production, secure env vars, authentication, rate-limiting, logging, and tests should be added.
