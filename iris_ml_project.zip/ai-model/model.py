"""ML Model Training Script
Trains XGBoost, CatBoost, and LightGBM on Iris dataset and saves models into models/ directory.
"""
import os
import pandas as pd
import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
import xgboost as xgb
from catboost import CatBoostClassifier
import lightgbm as lgb
import joblib
import json

os.makedirs('models', exist_ok=True)

def train_models():
    print("Loading Iris dataset...")
    iris = load_iris()
    X = pd.DataFrame(iris.data, columns=iris.feature_names)
    y = iris.target

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    print(f"Training set: {X_train.shape}, Test set: {X_test.shape}")

    xgb_model = xgb.XGBClassifier(n_estimators=100, max_depth=4, learning_rate=0.1, random_state=42, use_label_encoder=False, eval_metric='mlogloss')
    xgb_model.fit(X_train, y_train)
    xgb_pred = xgb_model.predict(X_test)
    xgb_acc = accuracy_score(y_test, xgb_pred)

    cat_model = CatBoostClassifier(iterations=100, depth=4, learning_rate=0.1, random_state=42, verbose=False)
    cat_model.fit(X_train, y_train)
    cat_pred = cat_model.predict(X_test)
    cat_acc = accuracy_score(y_test, cat_pred)

    lgb_model = lgb.LGBMClassifier(n_estimators=100, max_depth=4, learning_rate=0.1, random_state=42)
    lgb_model.fit(X_train, y_train)
    lgb_pred = lgb_model.predict(X_test)
    lgb_acc = accuracy_score(y_test, lgb_pred)

    ensemble_pred = []
    for i in range(len(X_test)):
        votes = [int(xgb_pred[i]), int(cat_pred[i]), int(lgb_pred[i])]
        ensemble_pred.append(max(set(votes), key=votes.count))
    ensemble_acc = accuracy_score(y_test, ensemble_pred)

    joblib.dump(xgb_model, 'models/xgb_model.pkl')
    joblib.dump(cat_model, 'models/cat_model.pkl')
    joblib.dump(lgb_model, 'models/lgb_model.pkl')

    metadata = {
        'feature_names': iris.feature_names,
        'target_names': iris.target_names.tolist(),
        'xgb_accuracy': float(xgb_acc),
        'cat_accuracy': float(cat_acc),
        'lgb_accuracy': float(lgb_acc),
        'ensemble_accuracy': float(ensemble_acc),
        'n_features': X.shape[1],
        'n_classes': len(np.unique(y))
    }

    with open('models/model_metadata.json', 'w') as f:
        json.dump(metadata, f, indent=2)

    print("Models saved to models/ directory")
    print("\nClassification Report (Ensemble):")
    print(classification_report(y_test, ensemble_pred, target_names=iris.target_names))

if __name__ == '__main__':
    train_models()
