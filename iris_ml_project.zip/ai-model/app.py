from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import joblib, json, os
import numpy as np

app = FastAPI(title='Iris Classification API', version='1.1.0')

app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*']
)

MODEL_DIR = os.path.join(os.path.dirname(__file__) or '.', 'models')

def load_models():
    try:
        xgb_model = joblib.load(os.path.join(MODEL_DIR, 'xgb_model.pkl'))
        cat_model = joblib.load(os.path.join(MODEL_DIR, 'cat_model.pkl'))
        lgb_model = joblib.load(os.path.join(MODEL_DIR, 'lgb_model.pkl'))
        with open(os.path.join(MODEL_DIR, 'model_metadata.json'), 'r') as f:
            metadata = json.load(f)
        return xgb_model, cat_model, lgb_model, metadata
    except Exception as e:
        print('Model load error:', e)
        return None, None, None, None

xgb_model, cat_model, lgb_model, metadata = load_models()

class PredictionInput(BaseModel):
    sepal_length: float = Field(..., ge=0)
    sepal_width: float = Field(..., ge=0)
    petal_length: float = Field(..., ge=0)
    petal_width: float = Field(..., ge=0)

class PredictionOutput(BaseModel):
    prediction: str
    confidence: float
    probabilities: dict
    model_votes: dict

@app.get('/')
def root():
    return {'message': 'Iris Classification API', 'status': 'ok'}

@app.get('/model-info')
def model_info():
    if metadata is None:
        raise HTTPException(status_code=503, detail='Models not available. Please run training.')
    return {
        'dataset': 'Iris',
        'models': ['XGBoost', 'CatBoost', 'LightGBM'],
        'features': metadata.get('feature_names', []),
        'classes': metadata.get('target_names', []),
        'accuracies': {
            'xgboost': metadata.get('xgb_accuracy'),
            'catboost': metadata.get('cat_accuracy'),
            'lightgbm': metadata.get('lgb_accuracy'),
            'ensemble': metadata.get('ensemble_accuracy')
        }
    }

@app.post('/predict', response_model=PredictionOutput)
def predict(inp: PredictionInput):
    if xgb_model is None or cat_model is None or lgb_model is None:
        raise HTTPException(status_code=503, detail='Models not loaded. Train models and restart the server.')

    features = np.array([[inp.sepal_length, inp.sepal_width, inp.petal_length, inp.petal_width]])
    xgb_pred = int(xgb_model.predict(features)[0])
    cat_pred = int(cat_model.predict(features)[0])
    lgb_pred = int(lgb_model.predict(features)[0])

    xgb_proba = xgb_model.predict_proba(features)[0]
    cat_proba = cat_model.predict_proba(features)[0]
    lgb_proba = lgb_model.predict_proba(features)[0]

    votes = [xgb_pred, cat_pred, lgb_pred]
    ensemble_pred = max(set(votes), key=votes.count)
    avg_proba = (np.array(xgb_proba) + np.array(cat_proba) + np.array(lgb_proba)) / 3.0

    class_name = metadata['target_names'][int(ensemble_pred)]
    confidence = float(avg_proba[int(ensemble_pred)])

    probabilities = { metadata['target_names'][i]: float(avg_proba[i]) for i in range(len(avg_proba)) }
    model_votes = {
        'xgboost': metadata['target_names'][int(xgb_pred)],
        'catboost': metadata['target_names'][int(cat_pred)],
        'lightgbm': metadata['target_names'][int(lgb_pred)]
    }

    return PredictionOutput(prediction=class_name, confidence=confidence, probabilities=probabilities, model_votes=model_votes)

if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host='0.0.0.0', port=8000)
