require('dotenv').config();
const express = require('express');
const cors = require('cors');
const connectDB = require('./config/db');

const app = express();
app.use(cors());
app.use(express.json());

// Connect to DB
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/iris_predictions';
connectDB(MONGO_URI).catch(err => console.error('DB connect failed:', err.message));

// Routes
app.get('/api/health', (req, res) => res.json({ status: 'ok' }));

app.use('/api/predict', require('./routes/predict'));
app.use('/api', require('./routes/stats'));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Backend running on port ${PORT}`));
