const mongoose = require('mongoose');

const predictionSchema = new mongoose.Schema({
  input: {
    sepal_length: { type: Number, required: true },
    sepal_width: { type: Number, required: true },
    petal_length: { type: Number, required: true },
    petal_width: { type: Number, required: true }
  },
  result: {
    prediction: String,
    confidence: Number,
    probabilities: Object,
    model_votes: Object
  },
  timestamp: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Prediction', predictionSchema);
