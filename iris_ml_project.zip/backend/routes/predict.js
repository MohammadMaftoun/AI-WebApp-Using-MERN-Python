const express = require('express');
const router = express.Router();
const axios = require('axios');
const Joi = require('joi');
const Prediction = require('../models/Prediction');

const schema = Joi.object({
  sepal_length: Joi.number().min(0).required(),
  sepal_width: Joi.number().min(0).required(),
  petal_length: Joi.number().min(0).required(),
  petal_width: Joi.number().min(0).required()
});

router.post('/', async (req, res) => {
  try {
    const { error, value } = schema.validate(req.body);
    if (error) return res.status(400).json({ error: error.details[0].message });

    const FASTAPI_URL = process.env.FASTAPI_URL || 'http://localhost:8000';
    const response = await axios.post(`${FASTAPI_URL}/predict`, value, { timeout: 5000 });

    // Save prediction (best-effort)
    const pred = new Prediction({
      input: value,
      result: response.data
    });
    await pred.save().catch(err => console.warn('Failed to save prediction:', err.message));

    res.json(response.data);
  } catch (err) {
    console.error('Prediction route error:', err.message);
    res.status(500).json({ error: 'Prediction failed', details: err.message });
  }
});

module.exports = router;
