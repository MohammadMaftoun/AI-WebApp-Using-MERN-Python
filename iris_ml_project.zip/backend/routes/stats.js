const express = require('express');
const router = express.Router();
const Prediction = require('../models/Prediction');

router.get('/history', async (req, res) => {
  try {
    const limit = parseInt(req.query.limit, 10) || 10;
    const predictions = await Prediction.find().sort({ timestamp: -1 }).limit(limit);
    res.json(predictions);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch history' });
  }
});

router.get('/stats', async (req, res) => {
  try {
    const total = await Prediction.countDocuments();
    const predictions = await Prediction.find();

    const classCount = {};
    predictions.forEach(p => {
      const cls = p.result && p.result.prediction ? p.result.prediction : 'unknown';
      classCount[cls] = (classCount[cls] || 0) + 1;
    });

    res.json({ total_predictions: total, class_distribution: classCount });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch stats' });
  }
});

module.exports = router;
