import React from 'react';
import PredictionForm from './components/PredictionForm';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="header">
        <h1>🌸 Iris Flower Classifier</h1>
        <p>Multi-class classification using ensemble ML models</p>
      </header>
      <main className="container">
        <PredictionForm />
      </main>
    </div>
  );
}

export default App;
