import React from 'react';

const getClassColor = (className) => {
  const colors = {
    'setosa': '#10b981',
    'versicolor': '#3b82f6',
    'virginica': '#8b5cf6'
  };
  return colors[className.toLowerCase()] || '#6b7280';
};

export default function Result({ result }) {
  return (
    <div className="result">
      <h3>Prediction Result</h3>
      <div className="prediction-badge" style={{ backgroundColor: getClassColor(result.prediction) }}>
        {result.prediction}
      </div>
      <div className="confidence">Confidence: {(result.confidence*100).toFixed(2)}%</div>

      <div className="probabilities">
        <h4>Class Probabilities</h4>
        {Object.entries(result.probabilities).map(([cls, prob]) => (
          <div key={cls} className="probability-bar">
            <span className="class-name">{cls}</span>
            <div className="bar-container">
              <div className="bar-fill" style={{ width: `${prob*100}%`, backgroundColor: getClassColor(cls) }} />
            </div>
            <span className="percentage">{(prob*100).toFixed(1)}%</span>
          </div>
        ))}
      </div>

      <div className="model-votes">
        <h4>Model Votes</h4>
        <div className="votes-grid">
          {Object.entries(result.model_votes).map(([model, vote]) => (
            <div key={model} className="vote-item"><strong>{model}</strong>: {vote}</div>
          ))}
        </div>
      </div>
    </div>
  );
}
