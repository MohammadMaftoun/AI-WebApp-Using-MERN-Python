import React, { useState } from 'react';
import axios from 'axios';
import Result from './Result';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

export default function PredictionForm() {
  const [input, setInput] = useState({
    sepal_length: '',
    sepal_width: '',
    petal_length: '',
    petal_width: ''
  });
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const v = e.target.value;
    setInput(prev => ({ ...prev, [e.target.name]: v === '' ? '' : parseFloat(v) }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setResult(null);

    try {
      // Validate before sending
      for (const k of ['sepal_length','sepal_width','petal_length','petal_width']) {
        if (input[k] === '' || Number.isNaN(input[k])) {
          throw new Error('All fields are required and must be numbers.');
        }
      }

      const response = await axios.post(`${API_URL}/predict`, input);
      setResult(response.data);
    } catch (err) {
      alert('Prediction failed: ' + (err.response?.data?.error || err.message));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="card prediction-card">
      <h2>Make a Prediction</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-grid">
          <label>Sepal Length (cm)</label>
          <input type="number" name="sepal_length" step="0.1" min="0" max="10" value={input.sepal_length} onChange={handleChange} required />
          <label>Sepal Width (cm)</label>
          <input type="number" name="sepal_width" step="0.1" min="0" max="10" value={input.sepal_width} onChange={handleChange} required />
          <label>Petal Length (cm)</label>
          <input type="number" name="petal_length" step="0.1" min="0" max="10" value={input.petal_length} onChange={handleChange} required />
          <label>Petal Width (cm)</label>
          <input type="number" name="petal_width" step="0.1" min="0" max="10" value={input.petal_width} onChange={handleChange} required />
        </div>
        <button className="btn-primary" type="submit" disabled={loading}>{loading ? 'Predicting...' : 'Predict Species'}</button>
      </form>

      {result && <Result result={result} />}
    </div>
  );
}
